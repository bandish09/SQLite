//
//  Utils.swift
//  SqliteDemo
//
//  Created by BANDISH on 8/2/17.
//  Copyright © 2017 BANDISH. All rights reserved.
//

import UIKit

class Utils: NSObject {

}

func displayAlert(_ title: String, message: String, completion:((_ index: Int) -> Void)?, otherTitles: String? ...) {
    
    if message.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) == "" {
        return
    }
    
    let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
    
    if !otherTitles.isEmpty {
        var i = 0
        for title in otherTitles {
            if let title = title {
                alert.addAction(UIAlertAction(title: title, style: .default, handler: { (_) in
                    if (completion != nil) {
                        i += 1
                        completion!(i)
                    }
                }))
            }
        }
    } else {
        alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { (_) in
            if (completion != nil) {
                completion!(0)
            }
        }))
    }
    
    DispatchQueue.main.async {
        AppInfo.appDelegate.window?.rootViewController!.present(alert, animated: true, completion: nil)
    }
}

func displayAlert(_ title: String, message: String) {
    displayAlert(title, message: message, completion: nil)
}

func displayAlert(_ message: String) {
    displayAlert(AppInfo.Title, message: message)
}
