//
//  ViewController.swift
//  SqliteDemo
//
//  Created by BANDISH on 8/1/17.
//  Copyright © 2017 BANDISH. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var tblDepartment : UITableView!
    var filteredTableData = [[String: Any]]()
    var resultSearchController = UISearchController()
    var deptArr = [[String: Any]]()
    var indexPath = NSIndexPath()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Departments"
        
        // if searchview will not hide when pushing to another view this property is used for that
        //self.definesPresentationContext = true
        
        
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tapOnView))
//        self.view.addGestureRecognizer(tapGesture)
        
        self.resultSearchController = ({
            let controller = UISearchController(searchResultsController: nil)
            controller.searchResultsUpdater = self
            controller.dimsBackgroundDuringPresentation = false
            //controller.hidesNavigationBarDuringPresentation = false
            controller.searchBar.sizeToFit()
            controller.searchBar.delegate = self
            self.tblDepartment.tableHeaderView = controller.searchBar
            return controller
        })()
        
        fetchRecord()
        
    }

    func hideSearchBar(){
        if self.resultSearchController.isActive{
            self.resultSearchController.isActive = false
            self.resultSearchController.searchBar.text = ""
            self.resultSearchController.searchBar.resignFirstResponder()
            self.resultSearchController.searchBar.showsCancelButton = false
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
            self.hideSearchBar()
    }
    
    func tapOnView(){
        self.view.endEditing(true)
    }
    
    func fetchRecord(){
        //fetch data from database
        let arr = ["_id", "id", "name"]
        self.deptArr = AppInfo.shareInstance.fetch_data("department", fields_arr: arr, condition: "")
        print("deptArr:::: \(deptArr)")
        self.RelodData()
    }
    
    func RelodData() {
        self.tblDepartment.reloadData()
    }
    
    func deletRecord(){
        let dict = self.deptArr[self.indexPath.row]
        let condition = "where _id = \(dict["_id"] ?? "")"
        let isDeleted = AppInfo.shareInstance.delete_record("department", condition: condition)
        if isDeleted{
            self.fetchRecord()
            displayAlert("Record delete Successfully")
        }else{
            displayAlert("Try again")
        }
    }
    
    @IBAction func btnAddPressed(_ sender: Any) {
        
        let alert = UIAlertController(title: "Department", message: "Enter Name", preferredStyle: .alert)
        alert.addTextField { (textfield) in
            textfield.placeholder = "MCA"
        }
        
        let btnAdd = UIAlertAction.init(title: "Add", style: .default) { (alertview) in
            if let deptName = alert.textFields?[0].text {
                
                if deptName.characters.count != 0{
                    let dictDepartment = ["id": 10, "name":deptName] as [String : Any]
                    let rowId = AppInfo.shareInstance.insertRecord(dictDepartment, key_arr: AppInfo.deptFieldsArr, table_name: "department")
                    print("rowId::::: \(rowId)")
                    //self.deptArr.append(deptName)
                    self.fetchRecord()
                }
                else{
                    self.dismiss(animated: true, completion: nil)
                    let alertErr = UIAlertController(title: "Department", message: "Plz Enter Department Name", preferredStyle: .alert)
                    let btnOk = UIAlertAction.init(title: "Ok", style: .default, handler: nil)
                    alertErr.addAction(btnOk)
                    self.present(alertErr, animated: true, completion: nil)
                }
            }
        }
        
        let btnCancel = UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(btnAdd)
        alert.addAction(btnCancel)
        self.present(alert, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}


extension ViewController: UITableViewDataSource, UITableViewDelegate{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.resultSearchController.isActive) {
            return self.filteredTableData.count
        }
        else {
            return deptArr.count 
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "deptCell") as! customDeptCell
        cell.selectionStyle = .none
        
        var model = [String: Any]()
        if (self.resultSearchController.isActive) {
            model = self.filteredTableData[(indexPath as NSIndexPath).row]
        }
        else {
            model = self.deptArr[(indexPath as NSIndexPath).row]
        }
        
        cell.txtName.delegate = self
        cell.setUpModel(model: model)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("didselect call")
        
        DispatchQueue.main.async(execute: {
            let ObjStudentViewController = self.storyboard?.instantiateViewController(withIdentifier: "studentList") as! studentList
//            ObjStudentViewController.deptId = model as! Department
            self.navigationController?.pushViewController(ObjStudentViewController, animated: true)
            
        })
    }
    
    // Override to support conditional editing of the table view.
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let moreRowAction = UITableViewRowAction(style: UITableViewRowAction.Style.default, title: "Update", handler:{action, indexpath in
            self.tblDepartment.setEditing(false, animated: true)
            let cell = tableView.cellForRow(at: indexPath) as! customDeptCell
            cell.txtName.isUserInteractionEnabled = true
            cell.txtName.becomeFirstResponder()
            self.indexPath = indexPath as NSIndexPath
        });
        moreRowAction.backgroundColor = UIColor(red: 0.298, green: 0.851, blue: 0.3922, alpha: 1.0);

        let deleteRowAction = UITableViewRowAction(style: UITableViewRowAction.Style.default, title: "Delete", handler:{action, indexpath in
            print("DELETE•ACTION");
            self.indexPath = indexPath as NSIndexPath
            displayAlert("SqliteDemo", message: "Are you sure want to delete this record?", completion: { (index) in
                if index == 1{
                    self.deletRecord()
                }
            }, otherTitles: "Cancel", "Yes")
        });
        
        return [deleteRowAction, moreRowAction];
    }
}

extension ViewController: UISearchResultsUpdating, UISearchBarDelegate{
    func updateSearchResults(for searchController: UISearchController) {
        print("helloo")
        self.updateSearchResultsForSearchController(searchController: searchController)
    }
    
    func updateSearchResultsForSearchController(searchController: UISearchController)
    {
        filteredTableData.removeAll(keepingCapacity: false)
        let searchPredicate = NSPredicate(format: "name CONTAINS[c] %@", searchController.searchBar.text!)
        let array = (deptArr as NSArray).filtered(using: searchPredicate)
        filteredTableData = array as! [[String: Any]]
        self.RelodData()
    }
    
//    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {
//        return true
//    }
//    
//    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
//        self.resultSearchController.searchBar.resignFirstResponder()
//    }
    
}

extension ViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        print("return call")
        
        let cell = self.tblDepartment.cellForRow(at: self.indexPath as IndexPath) as! customDeptCell
        print("new text ::: \(String(describing: cell.txtName.text))")
        //update record and reload table with fetch data
        
        var dict = self.deptArr[self.indexPath.row]
        dict["name"] = cell.txtName.text
        let condition = "where _id = \(dict["_id"] ?? "")"
        let isUpdate = AppInfo.shareInstance.updateData(dict, key_arr: AppInfo.deptFieldsArr, table_name: "department", condition: condition)
        if !isUpdate{
            displayAlert("Record not Updated.")
        } else{
            self.hideSearchBar()
            self.fetchRecord()
            cell.txtName.isUserInteractionEnabled = false
            textField.resignFirstResponder()
            displayAlert("Record Updated.")
        }
        return true
    }
}



