//
//  customDeptCell.swift
//  SqliteDemo
//
//  Created by BANDISH on 8/4/17.
//  Copyright © 2017 BANDISH. All rights reserved.
//

import UIKit

class customDeptCell: UITableViewCell {

    @IBOutlet weak var txtName: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.txtName.isUserInteractionEnabled = false
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    func setUpModel(model: Dictionary<String, Any>){
        print("setup model call")
        self.txtName.text = model["name"] as? String
    }
}
