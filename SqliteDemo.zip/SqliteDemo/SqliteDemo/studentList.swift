//
//  studentList.swift
//  SqliteDemo
//
//  Created by BANDISH on 8/1/17.
//  Copyright © 2017 BANDISH. All rights reserved.
//

import UIKit

class studentList: UIViewController {

    
    @IBOutlet weak var tblStudent : UITableView!
    var studentArr = [String]()

    
    override func viewDidLoad() {
        super.viewDidLoad()

        studentArr.append("a")
        studentArr.append("b")
        studentArr.append("c")
        studentArr.append("d")
        studentArr.append("e")
        studentArr.append("f")
        studentArr.append("g")
        studentArr.append("h")
        studentArr.append("i")
    
    }

    
    private func RelodData() {
        //fetch data from database
        
        self.tblStudent.reloadData()
        
    }
    
    @IBAction func btnAddPressed(_ sender: Any) {
        
        let alert = UIAlertController(title: "Student", message: "Enter Name", preferredStyle: .alert)
        alert.addTextField { (textfield) in
            textfield.placeholder = "John"
        }
        
        let btnAdd = UIAlertAction.init(title: "Add", style: .default) { (alertview) in
            if let studentName = alert.textFields?[0].text {
                
                if studentName.characters.count != 0{
                    let dictStudent = ["name":studentName]
                    self.studentArr.append(studentName)
                    self.RelodData()
                }
                else{
                    self.dismiss(animated: true, completion: nil)
                    let alertErr = UIAlertController(title: "Department", message: "Plz Enter Student Name", preferredStyle: .alert)
                    let btnOk = UIAlertAction.init(title: "Ok", style: .default, handler: nil)
                    alertErr.addAction(btnOk)
                    self.present(alertErr, animated: true, completion: nil)
                }
            }
        }
        
        let btnCancel = UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(btnAdd)
        alert.addAction(btnCancel)
        self.present(alert, animated: true, completion: nil)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}

extension studentList: UITableViewDataSource, UITableViewDelegate{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return studentArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "studentCell")!
        cell.textLabel?.text = studentArr[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("didselect call")
        DispatchQueue.main.async(execute: {
            let ObjStudentViewController = self.storyboard?.instantiateViewController(withIdentifier: "studentList") as! studentList
            //            ObjStudentViewController.deptId = model as! Department
            self.navigationController?.pushViewController(ObjStudentViewController, animated: true)
            
        })
    }
}
