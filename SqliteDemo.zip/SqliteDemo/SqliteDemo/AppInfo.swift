//
//  AppInfo.swift
//  SqliteDemo
//
//  Created by BANDISH on 8/1/17.
//  Copyright © 2017 BANDISH. All rights reserved.
//

import UIKit

class AppInfo: NSObject {
    static var shareInstance = DBManager.sharedInstance
    static let deptFieldsArr = ["id", "name"]
    static let studFieldArr = ["id", "name", "dept_id"]
    static var appDelegate: AppDelegate { return UIApplication.shared.delegate as! AppDelegate }
    static var Title: String { return "SqliteDemo" }

}
