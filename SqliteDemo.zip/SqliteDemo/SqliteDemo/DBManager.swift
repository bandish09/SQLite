//
//  DBManager.swift
//  SqliteDemo
//
//  Created by BANDISH on 8/1/17.
//  Copyright © 2017 BANDISH. All rights reserved.
//

import UIKit
import Foundation

/*
You can use also like this

struct AppInfo {
    static var shareInstance = CommonParameter.sharedInstance
}

class CommonParameter: NSObject{
    static let sharedInstance = CommonParameter()
    var arrMonitorRegion = [String]()
}

AppInfo.shareInstance.arrMonitorRegion
*/

/*
https://stackoverflow.com/questions/24102775/accessing-an-sqlite-database-in-swift/28642293#28642293
*/

class DBManager: NSObject {
    var databasePath = ""
    static let sharedInstance = DBManager()
    static var database: OpaquePointer? = nil
    static var statement: OpaquePointer? = nil
    
    
    override init() {
        print("crete instance of single tone class")
    }
    
    func createTable(_ table_name: String, fields fields_arr: [String]) -> Bool {
        var docsDir: String
        var dirPaths: [Any]
        // Get the documents directory
        dirPaths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        docsDir = dirPaths[0] as! String
        //Build the path to the database file
        databasePath = URL(fileURLWithPath: docsDir).appendingPathComponent("SqliteDemo.db").absoluteString
        print("databasePath ::: \(databasePath)")
        var isSuccess: Bool = true
//        let filemgr = FileManager.default
        
//        if filemgr.fileExists(atPath: databasePath) == false {
//                print("file does not exist")
//        }
        
        let dbpath = databasePath.cString(using: String.Encoding.utf8)
        
        if sqlite3_open(dbpath, &DBManager.database) == SQLITE_OK {
            
            var create_qry: String = "CREATE TABLE IF NOT EXISTS \(table_name) (_id INTEGER PRIMARY KEY AUTOINCREMENT,"
            for i in 0..<fields_arr.count {
                if (fields_arr[i] == "id") {
                    create_qry = create_qry + ("\(fields_arr[i]) INTEGER,")
                }else {
                    create_qry = create_qry + ("\(fields_arr[i]) TEXT,")
                }
            }
            create_qry = create_qry + ("is_created TEXT, is_updated TEXT);")
            print("create qry:: \(create_qry)")
            let sql_stmt = create_qry.cString(using: String.Encoding.utf8)
            if sqlite3_exec(DBManager.database, sql_stmt, nil, nil, nil) != SQLITE_OK {
                isSuccess = false
                print("Failed to create table")
                sqlite3_close(DBManager.database)
                return isSuccess
            }
            else {
                isSuccess = true
                print("create database")
            }
        }
        return isSuccess;
    }

    func insertRecord(_ Table_Record: [String: Any], key_arr: [String], table_name: String) -> Int {
        var lastRowId: Int
        lastRowId = 0
        let dbpath = databasePath.cString(using: String.Encoding.utf8)
        
        
        /*let insert_stmt2 = "insert into \(table_name) (id,name)values(?,?)";
        
        if (sqlite3_prepare_v2(DBManager.database, insert_stmt2, -1, &DBManager.statement, nil) != SQLITE_OK) {  // prepare SQL
            print("not prepare")
        } else {
            print("continue")
            let idd = 101
            let namee = "You joined \"New Sample\""
            if (sqlite3_bind_int64(DBManager.statement, 1, sqlite3_int64(idd)) != SQLITE_OK) {            // bind 1
                print("intttt not binding")
            } else if (sqlite3_bind_text(DBManager.statement, 2, namee, -1, nil) != SQLITE_OK) {   // bind 2
                print("strrrrr not binding")
            } else if (sqlite3_step(DBManager.statement) != SQLITE_DONE) {                            // perform SQL
                print("step not binding")
            } else {
                
                lastRowId = Int(sqlite3_last_insert_rowid(DBManager.database))
                print("lastRowId \(lastRowId)")
            }

//            sqlite3_finalize(statement);
        }
   */
        
        
        
        if sqlite3_open(dbpath, &DBManager.database) == SQLITE_OK {
            var insert_qry = String()
            var insert_key_qry: String = "insert into \(table_name) ("
            var insert_value_qry: String = "values("
            for obj: String in key_arr {
                insert_key_qry = insert_key_qry + ("\(obj),")
                if obj == "id"{
                    let value: Int = Table_Record[obj] as? Int ?? 0
                    insert_value_qry = insert_value_qry + ("\(value),")
                } else{
                    let value: String = Table_Record[obj] as? String ?? ""
                    insert_value_qry = insert_value_qry + ("\"\(value)\",")
                }
                
            }
            insert_key_qry = insert_key_qry + ("is_created, is_updated)")
            insert_value_qry = insert_value_qry + ("\"\("0")\",\"\("0")\")")
            insert_qry = insert_qry + (insert_key_qry)
            insert_qry = insert_qry + (insert_value_qry)
            print("insert qry::: \(insert_qry)")
            let insert_stmt = insert_qry.cString(using: String.Encoding.utf8)
            sqlite3_prepare_v2(DBManager.database, insert_stmt, -1, &DBManager.statement, nil)
            if sqlite3_step(DBManager.statement) == SQLITE_DONE {
                lastRowId = Int(sqlite3_last_insert_rowid(DBManager.database))
            }
            else {
                return 0
            }
            sqlite3_reset(DBManager.statement)
        }
        return lastRowId;
    }
    
    func fetch_data(_ table_name: String, fields_arr: [String], condition: String) -> [[String: Any]] {
        
        let dbpath = databasePath.cString(using: String.Encoding.utf8)
        if sqlite3_open(dbpath, &DBManager.database) == SQLITE_OK {
            var SelectStatement: OpaquePointer?
            var record_dict: [String: Any]
            var SelectQry: String = "select "
            let lastField: String? = fields_arr.last
            for i in 0..<fields_arr.count {
                if fields_arr[i] == lastField {
                    SelectQry = SelectQry + ("\(fields_arr[i]) ")
                }
                else {
                    SelectQry = SelectQry + ("\(fields_arr[i]),")
                }
            }
            SelectQry = SelectQry + ("from \(table_name) \(condition)")
            let query_stmt = SelectQry.cString(using: String.Encoding.utf8)
            var resultArray = [[String: Any]]()
            if sqlite3_prepare_v2(DBManager.database, query_stmt, -1, &SelectStatement, nil) != SQLITE_OK {
                let errmsg = String(cString: sqlite3_errmsg(DBManager.database)!)
                print("error preparing select: \(errmsg)")
            }
            while sqlite3_step(SelectStatement) == SQLITE_ROW {
                record_dict = [String: Any]()
                for i in 0..<fields_arr.count {
                    if fields_arr[i] == "id"{
                        let intValue = sqlite3_column_int64(SelectStatement, Int32(i))
                        print("id = \(intValue); ", terminator: "")
                        record_dict[fields_arr[i]] = intValue
                    } else{
                        if let cString = sqlite3_column_text(SelectStatement, Int32(i)) {
                            let field_value = String(cString: cString)
                            record_dict[fields_arr[i]] = field_value
                        }
                    }
                }
                resultArray.append(record_dict)
            }
            if sqlite3_finalize(SelectStatement) != SQLITE_OK {
                let errmsg = String(cString: sqlite3_errmsg(DBManager.database)!)
                print("error finalizing prepared statement: \(errmsg)")
            }
            SelectStatement = nil
            return resultArray
        }
        return [[:]]
    }
    
    func updateData(_ Table_Record: [String: Any], key_arr: [String], table_name: String, condition: String) -> Bool {
        if sqlite3_open(databasePath, &DBManager.database) == SQLITE_OK {
            var update_query: String = "UPDATE \(table_name) SET "
            for obj: String in key_arr {
                if obj == "id"{
                    let value: Int = Table_Record[obj] as? Int ?? 0
                    update_query = update_query + ("\(obj)=\"\(value)\",")
                } else{
                    let value: String = Table_Record[obj] as? String ?? ""
                    update_query = update_query + ("\(obj)=\"\(value)\",")
                }
            }
            print("update quereyyyyy....\(update_query)")
            update_query = ((update_query as? NSString)?.substring(to: (update_query.characters.count ?? 0) - 1))!
            update_query = update_query + (" \(condition)")
            print("with condition ....\(update_query)")
            let query_statement = update_query.cString(using: String.Encoding.utf8)
            if sqlite3_prepare_v2(DBManager.database, query_statement, -1, &DBManager.statement, nil) == SQLITE_OK {
                while sqlite3_step(DBManager.statement) == SQLITE_DONE {
                    return true
                }
                sqlite3_finalize(DBManager.statement)
            }
        }
        return false
    }
    
    func delete_record(_ table_name: String, condition: String) -> Bool {
        if sqlite3_open(databasePath, &DBManager.database) == SQLITE_OK {
            //sqlite3_stmt *deleteStatement;
            let deleteQuery: String = "DELETE FROM \(table_name) \(condition)"
            print("Delete qry:: \(deleteQuery)")
            if sqlite3_prepare_v2(DBManager.database, deleteQuery.cString(using: String.Encoding.utf8), -1, &DBManager.statement, nil) == SQLITE_OK {
                //            //When binding parameters, index starts from 1 and not zero.
                //            sqlite3_bind_text(deleteStatement, 1, [name UTF8String], -1, SQLITE_TRANSIENT);
                if SQLITE_DONE == sqlite3_step(DBManager.statement) {
                    print("Record deleted successfully")
                    return true
                }
            }
            else {
                print("not deleted..")
                return false
            }
        }
        print("database not open")
        sqlite3_reset(DBManager.statement)
        return false
    }
}
