//
//  ViewController.swift
//  SQliteWithPod
//
//  Created by Bandish on 07/08/20.
//  Copyright © 2020 Bandish. All rights reserved.
//

import UIKit
import SQLite

func copyfileToDocs() -> String {
    let bundlePath = Bundle.main.path(forResource: "demo", ofType: ".sqlite")
    print(bundlePath!, "\n")
    let destPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
    let fullDestPath = NSURL(fileURLWithPath: destPath).appendingPathComponent("demo.sqlite")
    let fullDestPathString = fullDestPath?.path

    let fileManager = FileManager.default
    print(fileManager.fileExists(atPath: bundlePath!))
    do {
        try fileManager.copyItem(atPath: bundlePath!, toPath: fullDestPathString!)
        print("DB Copied")
    } catch {
        print("\n")
        print(error)
    }

    return fullDestPathString ?? ""
}


class ViewController: UIViewController {

    var dbPath:String = ""
    var db:Connection!
    var arrayDataFiltered:NSMutableArray = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dbPath = copyfileToDocs()
    }
    
    @IBAction func act_insert(_ sender: Any){
        do {
            db = try Connection(dbPath)
        } catch  {
            print("error to get data connection")
        }
        
        do {
            let stmt = try db.prepare("INSERT INTO student (id, name, city) VALUES (?,?,?)")
            let arr = [
                ["id": 1, "name":"bandish", "city":"botad"],
                ["id": 2, "name":"abhi", "city":"gandhinagar"],
                ["id": 3, "name":"vijay", "city":"palitana"]
            ]
            for dict in arr{
                try stmt.run(dict["id"] as? Binding, dict["name"] as? Binding, dict["city"] as? Binding)
                print("last row id \(db.lastInsertRowid)")
            }
        } catch  {
            print("not inserted")
        }
        
    }

    @IBAction func act_fetchData(_ sender: Any) {
        
        do {
            db = try Connection(dbPath)
            self.arrayDataFiltered.removeAllObjects()
            for student in try db.prepare("select * from student") {
                let arrayTemp = [ "id":student[0], "name":student[1]!, "city":student[2]]
                self.arrayDataFiltered.add(arrayTemp)
            }
            print("arry:::: \(self.arrayDataFiltered)")
        } catch  {
            print("error to get data connection")
        }
        
//        let student = Table("student")
//        do {
//            for user in try db.prepare(student) {
//                let id = try user.get(Expression<Int?>("id"))
//                let name = try user.get(Expression<String?>("name"))
//                let city = try user.get(Expression<String?>("city"))
//                let arrayTemp = ["id": id ?? 0, "name": name ?? "", "city": city ?? ""] as [String : Any]
//                self.arrayDataFiltered.add(arrayTemp)
//                print("arry:::: \(self.arrayDataFiltered)")
//            }
//        } catch  {
//            print("data not found")
//        }
    }
    
    
    @IBAction func act_update(_ sender: Any) {
        do {
            db = try Connection(dbPath)
            let name = "helloooo"
            let city = "hello22"
            let stmt = try db.prepare("UPDATE student SET name = ?, city = ? where id = ?")
            try stmt.run(name, city, 3)
        } catch  {
            print("error to get data connection")
        }
    }

    @IBAction func act_delete(_ sender: Any) {
        do {
            db = try Connection(dbPath)
            let stmt = try db.prepare("DELETE from student")
            try stmt.run()
        } catch  {
            print("error to get data connection")
        }
    }
    
}

