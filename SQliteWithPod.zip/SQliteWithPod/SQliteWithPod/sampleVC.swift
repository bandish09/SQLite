//
//  sampleVC.swift
//  SQliteWithPod
//
//  Created by Bandish on 08/10/20.
//  Copyright © 2020 Bandish. All rights reserved.
//

import UIKit
import SQLite

func copyfileToDocs2() -> String {
    let bundlePath = Bundle.main.path(forResource: "sample", ofType: ".sqlite")
    print(bundlePath!, "\n")
    let destPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
    let fullDestPath = NSURL(fileURLWithPath: destPath).appendingPathComponent("sample.sqlite")
    let fullDestPathString = fullDestPath?.path

    let fileManager = FileManager.default
    print(fileManager.fileExists(atPath: bundlePath!))
    do {
        try fileManager.copyItem(atPath: bundlePath!, toPath: fullDestPathString!)
        print("DB Copied")
    } catch {
        print("\n")
        print(error)
    }

    return fullDestPathString ?? ""
}



class sampleVC: UIViewController {

    var dbPath:String = ""
    var db:Connection!
    var arrayDataFiltered:NSMutableArray = NSMutableArray()

    
    let users = Table("users")
    let id = Expression<Int64>("id")
    let name = Expression<String?>("name")
    let email = Expression<String>("email")

    
    override func viewDidLoad() {
        super.viewDidLoad()

        dbPath = copyfileToDocs2()
    }
    

    @IBAction func btnCreate(_ sender: Any) {
        do
        {
            let db = try Connection(dbPath)
            try db.run(users.create { t in
                t.column(id, primaryKey: true)
                t.column(name)
                t.column(email, unique: false)
            })
        } catch{
            print("table not created")
        }
    }
    
    @IBAction func btnInsert(_ sender: Any) {
        let insert = users.insert(or: .ignore, name <- "bandish",email <- "bandish@gmail.com")
         do {
             let db = try Connection(dbPath)
             let rowid = try db.run(insert)
             print("Last row id is ::\(rowid)")
         } catch  {
             print("error ro get data connection")
         }
    }
    
    
    @IBAction func btnfetch(_ sender: Any) {
        
        do {
            let db = try Connection(dbPath)
            for user in try db.prepare(users) {
                print("id: \(user[id]), name: \(String(describing: user[name])), email: \(user[email])")
            }
        } catch  {
            print("failed:::")
        }
        
        
    }
    
    @IBAction func btnUpdate(_ sender: Any) {
        
        do {
            let db = try Connection(dbPath)
            let alice = users.filter(id == 1)
//            try db.run(alice.update(email <- email.replace("bandish@gmail.com", with: "me.com")))
            try db.run(alice.update(email <- "Hello.com"))
            print("updated:::")
        } catch  {
            print("failed to update")
        }
    }
    
    @IBAction func btndelete(_ sender: Any) {
        do {
            let db = try Connection(dbPath)
//            let alice = users.filter(id == 1)
//            try db.run(alice.delete())
            // DELETE FROM "users" WHERE ("id" = 1)

            try db.run(users.delete())
            
            let totalRecord = try db.scalar(users.count) // 0
            // SELECT count(*) FROM "users"
            print("total record is: \(totalRecord)")
        } catch {
            print("failed: Delete")
        }
    }
    
    
    
    
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
